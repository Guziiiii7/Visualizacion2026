library(dplyr)
library(lubridate)
library(plotly)
library(htmltools)

# 1. GENERACIÓN DE DATOS DE COCA-COLA
set.seed(101)

dates <- seq(as.Date("2022-01-02"), as.Date("2022-12-25"), by = "day")
retailers <- c("Walmart", "CVS", "Costco", "Target")
prob_retailers <- c(0.45, 0.25, 0.20, 0.10)

brands <- c("Coca-Cola", "Dasani Water", "Diet Coke", "Sprite", "Powerade", "Fanta")
prob_brands <- c(0.25, 0.20, 0.18, 0.15, 0.12, 0.10)

states_df <- data.frame(
  Code = c('NY', 'CA', 'TX', 'FL', 'IL', 'PA', 'OH', 'GA'),
  State = c('New York', 'California', 'Texas', 'Florida', 'Illinois', 'Pennsylvania', 'Ohio', 'Georgia'),
  Lat = c(40.7128, 36.7783, 31.9686, 27.6648, 40.6331, 41.2033, 40.4173, 32.1656),
  Lon = c(-74.0060, -119.4179, -99.9018, -81.5158, -89.3985, -77.1945, -82.9071, -82.9001)
)

n <- length(dates)
selected_states_idx <- sample(1:nrow(states_df), n, replace = TRUE)

df <- data.frame(
  Date = dates,
  Quarter = paste("Qtr", quarter(dates)),
  Retailer = sample(retailers, n, replace = TRUE, prob = prob_retailers),
  Beverage_Brand = sample(brands, n, replace = TRUE, prob = prob_brands),
  State = states_df$State[selected_states_idx],
  Lat = states_df$Lat[selected_states_idx],
  Lon = states_df$Lon[selected_states_idx],
  Units_Sold = sample(1500:6000, n, replace = TRUE),
  Price_per_Unit = round(runif(n, 0.35, 0.55), 2)
) %>%
  mutate(
    Total_Sales = Units_Sold * Price_per_Unit,
    Operating_Profit = Total_Sales * round(runif(n, 0.35, 0.40), 2)
  )

# 2. CONSTRUCCIÓN DE LAS VISUALIZACIONES

# --- 1. Gráfico de Barras ---
ret_sum <- df %>%
  group_by(Retailer) %>%
  summarise(Total_Sales = sum(Total_Sales), Operating_Profit = sum(Operating_Profit), .groups = 'drop') %>%
  mutate(Cost = Total_Sales - Operating_Profit)

fig_bar <- plot_ly(ret_sum, x = ~Retailer, height = 320) %>%
  add_trace(y = ~Cost, name = 'Sales', type = 'bar', marker = list(color = '#3399ff')) %>%
  add_trace(y = ~Operating_Profit, name = 'Operating Profit', type = 'bar', marker = list(color = '#9370db')) %>%
  layout(barmode = 'stack', title = list(text = 'Total Sales and Operating Profit by Retailer'), margin = list(l=20, r=20, t=40, b=20), legend = list(orientation = "h", y = 1.1))

# --- 2. Tabla Interactiva ---
brand_summary <- df %>%
  group_by(Beverage_Brand) %>%
  summarise(Total_Sales = sum(Total_Sales), Units_Sold = sum(Units_Sold), Operating_Profit = sum(Operating_Profit), .groups = 'drop')

fig_table <- plot_ly(
  type = 'table', height = 320,
  header = list(values = c("Beverage Brand", "Total Sales", "Units Sold", "Operating Profit"), fill = list(color = '#0b1340'), align = 'left', font = list(color = 'white', size = 12)),
  cells = list(values = rbind(brand_summary$Beverage_Brand, paste0("$", format(round(brand_summary$Total_Sales), big.mark = ",")), format(brand_summary$Units_Sold, big.mark = ","), paste0("$", format(round(brand_summary$Operating_Profit), big.mark = ","))), fill = list(color = '#f4f6f8'), align = 'left', font = list(size = 11))
) %>% layout(title = list(text = 'Beverage Brand Performance'), margin = list(l=10, r=10, t=40, b=10))

# --- 3. Línea de Tendencia ---
qtr_sum <- df %>%
  group_by(Quarter) %>%
  summarise(Total_Sales = sum(Total_Sales), Operating_Profit = sum(Operating_Profit), .groups = 'drop')

fig_line <- plot_ly(qtr_sum, x = ~Quarter, height = 320) %>%
  add_trace(y = ~Total_Sales, name = 'Sales', type = 'scatter', mode = 'lines+markers', line = list(color = '#0080ff', width = 3)) %>%
  add_trace(y = ~Operating_Profit, name = 'Profit', type = 'scatter', mode = 'lines+markers', line = list(color = '#110066', width = 3)) %>%
  layout(title = list(text = 'Operating Profit Analysis by Quarter'), margin = list(l=20, r=20, t=40, b=20), legend = list(orientation = "h", y = 1.1))

# --- 4. Mapa Interactivo ---
st_sum <- df %>% group_by(State, Lat, Lon) %>% summarise(Total_Sales = sum(Total_Sales), .groups = 'drop')

fig_map <- plot_ly(
  st_sum, lon = ~Lon, lat = ~Lat, height = 320,
  text = ~paste0(State, ": $", format(round(Total_Sales), big.mark = ",")),
  type = 'scattergeo', mode = 'markers',
  marker = list(size = ~ (Total_Sales / max(st_sum$Total_Sales) * 25 + 8), color = '#3399ff', opacity = 0.8, line = list(width = 1, color = 'blue'))
) %>% layout(title = list(text = 'Sales by US State'), geo = list(scope = 'usa', projection = list(type = 'albers usa'), showland = TRUE, landcolor = "rgb(240, 240, 240)"), margin = list(l=0, r=0, t=40, b=0))

# 3. ACOMODO EN PANTALLA ÚNICA
header <- HTML("<h2 style='color:#0b1340; text-align:center;'>Coca-Cola Sales Dashboard</h2><hr>")

dashboard <- div(
  header,
  div(
    style = "display: grid; grid-template-columns: 1fr 1fr; gap: 15px;",
    div(fig_bar), div(fig_table), div(fig_line), div(fig_map)
  )
)

browsable(dashboard)

